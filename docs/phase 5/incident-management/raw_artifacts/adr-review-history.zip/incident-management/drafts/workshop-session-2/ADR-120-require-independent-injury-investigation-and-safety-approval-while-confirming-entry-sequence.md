---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Safety Management
- Clinic
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:02:41–0:03:43; 1:16:28–1:17:43; 1:21:43–1:28:42; 1:39:37–1:43:19)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-120: Require Independent Injury Investigation and Safety Approval While Confirming Entry Sequence

## Context and Problem Statement

Session 1 proposed immediate injury investigation without separate draft or validity-verification gates. Session 2 repeats that direction early, then discusses a management/AIR contribution before clinic or investigation-team work when shared access and dynamic supervisor assignment prove unresolved. The proposed preliminary contribution is different from confirming that the incident is valid. [S1 1:56:32–2:00:12; 3:56:40–3:57:24; S2 0:02:41–0:03:43; 1:25:14–1:28:42; 1:39:37–1:43:19.]

## Decision Drivers

- Keep each child investigation and lifecycle independent. [S2 1:17:03–1:17:43.]
- Obtain management and clinic contributions from the people who can supply them. [S2 1:23:29–1:25:07; 1:35:26–1:36:17.]
- Provide a workable assignment path before the investigation-team handoff. [S2 1:39:37–1:43:19.]

## Considered Options

- Independent injury investigation and safety approval, with the contribution-entry sequence unresolved.
- Immediate shared investigation containing all contributions (session 1 proposal).
- An initial leader/AIR contribution followed by clinic and investigation-team work (session 2 alternative).

## Decision Outcome

Chosen option: "Independent injury investigation and safety approval, with the contribution-entry sequence unresolved", because session 2 retains investigation and approval per child but questions how initial management information enters that case. Retain separate records for different injured associates and safety review from session 1. Master creation/completion and another child’s closure do not complete the injury. [S1 0:54:51–0:55:26; 3:56:40–3:57:24; S2 0:02:41–0:03:43; 1:17:03–1:17:43.]

Retain the intent to avoid an unnecessary initial incident-validity approval. Qualify the earlier absolute immediate-investigation sequence: session 2 introduces a leader contribution before further investigation, with sequential routing described explicitly near the end. No final agreement selects that sequence over the desired concurrent model. Do not implement either as a settled decision from this transcript alone. [S2 1:25:14–1:28:42; 1:39:37–1:43:19.]

The PIT equipment-selection discussion does not establish an injury validity gate. Other incident-type sequences still need confirmation. [S2 0:25:15–0:27:06.]

## Consequences

- Analysis: separating validity verification from contribution entry avoids adding a gate for the wrong purpose.
- Analysis: an initial sequential contribution could delay clinic editing or team work; a shared model instead requires a proven access and ownership mechanism.
- Analysis: independent child completion requires case-level action and effectiveness prerequisites; the transcript does not finalize them.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:02:41–0:03:43; 1:16:28–1:17:43; 1:21:43–1:28:42; 1:39:37–1:43:19. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-120 text](../workshop-session-1/ADR-120-start-injury-investigation-immediately-and-require-safety-approval.md).
- Evidence nature: explicit retained investigation direction; entry sequence reopened. Confidence: high for case independence; medium for workflow direction.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Select the leader/clinic/investigation sequence and define stage exit criteria with ADR-121.
- Unresolved: Confirm rejection/return routes, clinical updates after stage changes, and post-closure reopening.
- Unresolved: Keep session 1’s monitoring versus approval-closes-record conflict open; no fixed 30/60/90-day schedule is established.
- Unresolved: Confirm PIT and other type-specific workflow behavior separately rather than copying injury rules universally.
- Related records: ADR-118, ADR-121, ADR-123, ADR-124, ADR-126, ADR-128. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
