---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- PIT safety
- Property damage
- Vehicle incidents
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:04:18–0:19:45; 0:24:32–0:27:06; 1:14:13–1:14:26)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-126: Distinguish PIT Incidents and Vary Their Questions by Equipment Type

## Context and Problem Statement

The workshop agenda labels the topic property damage, but SIA clarifies that the process under discussion is its PIT program. Fork-truck and crane questions are substantially similar with equipment-dependent differences. General building, equipment, other-vehicle, or property damage can coexist with PIT and injury, and general property-damage scope is not fully designed. [S2 0:04:55–0:17:51.]

## Decision Drivers

- Make the PIT process recognizable at incident selection and prevent ambiguous property/vehicle terminology. [S2 0:05:15–0:08:30; 0:14:11–0:15:48.]
- Ask questions that apply to the selected equipment rather than one undifferentiated list. [S2 0:08:51–0:12:33.]
- Retain multiple impact types when one event involves PIT, injury, and other damage. [S2 0:14:11–0:16:46.]

## Considered Options

- An explicitly identified PIT incident path with equipment-dependent questions.
- Use undifferentiated property damage for all PIT reporting (opening ambiguity).
- Split every equipment category into unrelated applications (analyst-derived alternative; not requested).

## Decision Outcome

Chosen option: "An explicitly identified PIT incident path with equipment-dependent questions", because SIA identifies a distinct program and similar questions with equipment-specific differences. Make PIT identifiable in the initial incident-type selection and route its data collection by selected equipment. Keep general property damage and other vehicle impacts distinguishable, including where they coexist under one event. Do not rename all property damage to PIT or assume every powered/automated device belongs to that program. [S2 0:05:15–0:12:33; 0:14:11–0:19:45; 1:14:13–1:14:26.]

The final native object/subtype boundary is not selected: vehicle/PIT versus a separate incident type are discussed. Cranes are described within the common intake context but with different questions/reporting; automated trolleys are described as not currently on the PIT form. Confirm the controlled equipment classification rather than deriving membership from these examples. [S2 0:11:46–0:14:43; 0:18:13–0:19:45.]

Equipment selection must be available early enough to drive the relevant questions. A separate supervisor validation step is raised as a possible means, not chosen. Do not add a generic validity gate merely to collect the equipment type. Damage costs are requested for relevant PIT/property damage, but costing fields and rollup rules are not specified. [S2 0:11:15–0:11:46; 0:25:15–0:27:06.]

## Consequences

- Analysis: an explicit PIT boundary improves routing and reporting without forcing non-PIT damage through the same form.
- Analysis: equipment-driven configuration requires a governed category list and question applicability rules.
- Analysis: a PIT incident with injury or other damage may produce several linked records; the counting and creation model must align with ADR-118.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:04:18–0:19:45; 0:24:32–0:27:06; 1:14:13–1:14:26.
- Evidence nature: explicit domain boundary and configurable-question direction. Confidence: high for distinction; medium for final taxonomy.
- New proposal, not approval or implementation evidence. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Obtain the referenced PIT Visio/form and validate equipment categories, conditional questions, and any truly different workflows; those artifacts were not supplied.
- Unresolved: Confirm native vehicle subtype versus distinct incident-type implementation and the terminology used by Security and reporting users.
- Unresolved: Resolve general property-damage and other-vehicle scope; the workshop does not approve their exclusion from the project.
- Unresolved: Define cost capture, ownership, and aggregation before treating damage-cost reporting as configured.
- Unresolved: Confirm PIT investigation/approval routing and any early equipment-entry step; no final workflow was completed before lunch.
- Related records: ADR-118, ADR-119, ADR-120, ADR-124, ADR-125. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
