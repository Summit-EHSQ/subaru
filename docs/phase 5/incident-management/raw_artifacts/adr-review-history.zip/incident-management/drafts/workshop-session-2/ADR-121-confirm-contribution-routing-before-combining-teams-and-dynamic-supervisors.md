---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Employee Management
- Clinic
- Safety Management
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:35:54–0:40:25; 1:18:12–1:28:58; 1:31:46–1:35:23; 1:39:14–1:43:19)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-121: Confirm Contribution Routing Before Combining Teams and Dynamic Supervisors

## Context and Problem Statement

The prior draft selected a shared stage with stable team membership and the injured associate’s dynamically resolved supervisor, while noting feasibility was unverified. Session 2 explicitly challenges that combination: the described investigation group is static, the initial contributor may be the accompanying management member, and that person may differ from the assigned supervisor responsible for corrective actions. [S1 ADR-121; S2 1:25:14–1:28:24; 1:31:46–1:34:14.]

## Decision Drivers

- Give the actual contributor access to enter the AIR. [S2 1:18:31–1:20:24; 1:39:37–1:40:46.]
- Preserve the difference between the accompanying management member and the associate’s assigned group leader. [S2 1:27:37–1:28:24; 1:31:46–1:34:14.]
- Support clinic and safety contributions without assuming an unproven group-assignment capability. [S2 1:24:19–1:28:42.]

## Considered Options

- Keep routing open while confirming contributor identity, access, and handoffs.
- A shared static investigation group plus additional dynamic supervisor participation (desired, not demonstrated).
- Sequential initial management contribution, clinic contribution, and safety/team work (discussed alternative).
- Select an initial contributor during intake and route that work to the selected person (requested, not finalized).

## Decision Outcome

Chosen option: "Keep routing open while confirming contributor identity, access, and handoffs", because session 2 exposes a material gap in the mechanism selected in the first draft. Preserve the requirement for distinct contributors to enter their own information and the desire for concurrent work. Do not claim that a static investigation group can automatically include each injured associate’s changing supervisor, or that sequential routing has been accepted as its replacement. [S2 1:24:19–1:28:58.]

Model the required responsibilities distinctly in the design: initial management/AIR contributor, clinical contributor, assigned supervisor for countermeasure work where applicable, and safety review. The accompanying management member is not necessarily the assigned supervisor or caller. The group disputes defaulting all work to the assigned supervisor when another member must enter the initial account. The request to select the initial contributor at intake is a candidate solution, not a completed routing specification. [S2 1:27:37–1:28:24; 1:31:46–1:35:23; 1:39:14–1:43:19.]

Session 2’s claims about platform limitations are workshop explanations to validate, not independently verified product facts. The Visio/flowchart and question sets discussed during the session are not attached here. [S2 1:24:08–1:28:58.]

## Consequences

- Analysis: the selected user must have effective edit access; receiving a notification or knowing a master number does not establish it.
- Analysis: using the caller as the default contributor fails where callers are anonymous, injured, or only witnesses.
- Analysis: a sequential fallback changes the parallel-work requirement and needs an explicit business tradeoff rather than a silent configuration substitution.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:35:54–0:40:25; 1:18:12–1:28:58; 1:31:46–1:35:23; 1:39:14–1:43:19. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-121 text](../workshop-session-1/ADR-121-use-a-shared-investigation-team-with-the-injured-associates-supervisor.md).
- Evidence nature: explicit unmet collaboration requirement and implementation conflict. Confidence: high that routing remains unresolved.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Confirm the shared-versus-sequential design after reviewing the actual process diagram and AIR/job-process-analysis questions.
- Unresolved: Define supervisor-data mapping, missing relationship fallback, absence coverage, initial-person selection, and reassignment. ADR-060 does not prove the required mapping already exists.
- Unresolved: Prove effective record access for both static team members and the initial contributor, including post-handoff access.
- Unresolved: Validate simultaneous saves and change attribution if shared editing remains selected.
- Unresolved: Confirm readiness indicators and return paths without confusing an informational checkbox with protected edit authority.
- Related records: ADR-060, ADR-120, ADR-122, ADR-123, ADR-127, ADR-128. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
