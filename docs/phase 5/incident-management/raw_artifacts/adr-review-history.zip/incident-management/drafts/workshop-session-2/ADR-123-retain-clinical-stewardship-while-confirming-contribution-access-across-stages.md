---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Clinic
- Safety Management
- OHM
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:29:06–0:30:33; 1:24:19–1:28:24; 1:35:26–1:36:17)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-123: Retain Clinical Stewardship While Confirming Contribution Access Across Stages

## Context and Problem Statement

Session 1 assigns evolving clinical data and injury/event association judgment to medical professionals. Session 2 explicitly says Security would not decide whether to reopen an earlier clinical case. It also reopens the access model under which the clinic can enter its contribution, challenging the earlier shared-stage guarantee. [S1 3:35:20–3:42:32; S2 0:29:06–0:30:33; 1:24:19–1:28:24.]

## Decision Drivers

- Keep clinical reopening and association decisions with medical professionals. [S2 0:29:42–0:30:33.]
- Preserve the clinic’s independent questions and the associate’s account. [S2 1:24:19–1:25:07; 1:35:26–1:36:17.]
- Allow evolving clinical data to be maintained without claiming an unverified workflow-access mechanism. [S1 1:08:20–1:15:51; S2 1:25:14–1:28:24.]

## Considered Options

- Clinical stewardship with access timing confirmed through the contribution-routing design.
- Security decides whether a later injury report belongs to an earlier clinical case (explicitly disclaimed in session 2).
- Restrict all clinical changes to the current non-clinical workflow owner (earlier discussed alternative).

## Decision Outcome

Chosen option: "Clinical stewardship with access timing confirmed through the contribution-routing design", because medical judgment remains with the clinic even while workflow participation is being reconsidered. Preserve the clinic’s ownership of injury information and case-by-case determination of whether later symptoms relate to an existing event/case. Security may supply the event reference; it does not make that medical reopening decision. [S1 3:39:00–3:42:32; S2 0:29:06–0:30:33.]

Preserve session 1’s proposal to keep an injury as its own record when detached from an unrelated event. Session 2’s broader relinking discussion does not define a new clinical merge or counting rule. Qualify the earlier assertion that the clinic edits without any sequential clinic stage: concurrent contribution is still desired, but sequential routing is now an unresolved alternative under ADR-121. Ownership is established more clearly than the mechanism for continuous edit access. [S1 3:41:36–3:42:32; S2 0:44:28–0:48:21; 1:24:19–1:28:24.]

Clinical interviewing of the associate does not replace the management member’s own AIR account; ADR-128 preserves that distinction. [S2 1:35:26–1:36:17.]

## Consequences

- Analysis: preserving medical authority avoids assigning clinical case relationships from a dispatch call alone.
- Analysis: a sequential workflow may need an additional explicit path for clinical updates after the clinic’s stage ends.
- Analysis: detaching, reopening, and correcting a case can affect historical reporting and approvals, so these operations need defined rules before implementation.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:29:06–0:30:33; 1:24:19–1:28:24; 1:35:26–1:36:17. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-123 text](../workshop-session-1/ADR-123-give-clinical-professionals-ongoing-injury-case-stewardship.md).
- Evidence nature: explicit clinical authority; unresolved entry timing. Confidence: high for clinical judgment; medium for access design.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Confirm ongoing clinical edit access during later stages and after closure, and its relationship to safety approval.
- Unresolved: Retain pending clinic leadership agreement and Intelex/OHM data ownership; session 2 supplies no confirmation.
- Unresolved: Define merge versus append, original-report preservation, event-association audit history, and counting behavior.
- Unresolved: Resolve standalone-case behavior against the eventual master-creation rule in ADR-118.
- Related records: ADR-064, ADR-118, ADR-120, ADR-121, ADR-128. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
