---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Intelex Platform
- Security intake
- Clinic
- Safety Management
- Environmental Management
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:59:54–1:02:38; 1:18:12–1:20:24; 1:29:06–1:31:46)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-122: Scope Incident Visibility to Defined Roles and Confirm Medical-Content Boundaries

## Context and Problem Statement

Session 1 distinguishes enterprise leadership access and section-scoped representatives while leaving injury-detail visibility open. Session 2 considers injury access for defined safety, clinic, environmental, and potentially Security groups; ordinary floor users remain excluded. It also identifies a real data-entry problem: unrelated personal medical information sometimes appears in the AIR. [S1 3:19:20–3:23:07; S2 0:59:54–1:02:38.]

## Decision Drivers

- Enable the defined specialist groups to access the records they contribute to or need to review. [S2 0:59:54–1:00:41; 1:18:12–1:20:24.]
- Exclude ordinary floor users from broad incident access. [S2 1:00:12–1:00:41.]
- Distinguish current incident information from unrelated personal medical content in free text. [S2 1:01:20–1:02:38; 1:29:06–1:31:46.]

## Considered Options

- Defined role/group access with separately confirmed content and organizational scope.
- General access for everyone in the building (raised but not chosen as an operational policy).
- Restrict all current-incident detail to clinic/safety alone (discussed contrast).

## Decision Outcome

Chosen option: "Defined role/group access with separately confirmed content and organizational scope", because session 2 favors access for named operational groups rather than ordinary floor users. Carry forward session 1’s proposed enterprise leadership and section-representative scopes as unresolved implementation inputs, not as permission to grant all groups unrestricted clinical access. Session 2 supports broader specialist injury visibility and considers Security access acceptable in principle, but it does not produce the complete role/type/field/stage matrix. [S1 3:19:20–3:23:07; S2 0:59:54–1:01:19.]

Record the directional willingness for the contributing supervisor to see current incident-related classifications and treatment details. The team explicitly leaves room for internal follow-up. Preserve the separate concern about irrelevant medical history in AIR narrative; coaching/training is the response discussed, not an implemented automated content screen or demonstrated permission boundary. [S2 1:01:20–1:02:38; 1:29:06–1:31:46.]

Statements in the workshop about whether legal restrictions exist are participant views, not verified legal determinations. They do not authorize access beyond the agreed operational scope. Reporting without identifying individuals is mentioned; audience, de-identification rules, and output fields remain unselected. [S2 1:00:48–1:02:38; 1:31:28–1:31:46.]

## Consequences

- Analysis: broader specialist access can support cross-discipline work, while increasing exposure if irrelevant personal details enter a common narrative.
- Analysis: coaching improves entry practice but cannot itself enforce confidentiality once content is stored.
- Analysis: notifications, summaries, search, and drill-through must follow the final permissions; notification membership alone does not create edit authority.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:59:54–1:02:38; 1:18:12–1:20:24; 1:29:06–1:31:46. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-122 text](../workshop-session-1/ADR-122-scope-event-visibility-by-role-and-organizational-section.md).
- Evidence nature: explicit broader specialist access direction with unresolved content boundary. Confidence: medium.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Confirm exact defined groups, organizational scope, Security access, and current-incident medical fields; do not infer universal leadership clinical visibility.
- Unresolved: Define handling of inappropriate medical content already entered, including correction authority and retained history.
- Unresolved: Resolve workflow-responsibility access versus browsing scope and continued access after handoff.
- Unresolved: Confirm clinic-provider provisioning without assuming supplier-portal authentication; ADR-061 remains unchanged.
- Unresolved: Define reporting audiences and any required de-identification behavior.
- Related records: ADR-061, ADR-082, ADR-121, ADR-125, ADR-127, ADR-128. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
