---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Safety Management
- Environmental Management
- Security intake
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:02:41–0:04:01; 0:21:18–0:23:56; 0:43:41–0:48:21; 1:14:36–1:17:43; 1:43:19–1:49:31)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-118: Group Related Incidents Under an Event with Independent Lifecycles

## Context and Problem Statement

Session 1 proposed a master intake for all events. Session 2 reaffirms the need to group related incidents, while debating Security creating a master and initial children versus specialist-created children. Near the end, an alternative puts event grouping after investigation; another participant challenges the resulting manual work. The transcript stops for lunch without resolving that dispute. [S1 3:53:40–3:54:50; S2 0:21:18–0:23:56; 1:43:19–1:49:31.]

## Decision Drivers

- Keep the collective event discoverable rather than leaving separate forms disconnected. [S2 0:21:18–0:22:54; 0:50:07–0:50:26.]
- Let different incident investigations complete independently. [S2 1:14:46–1:17:43.]
- Correct missed or wrongly grouped impacts as evidence develops. [S2 0:44:28–0:48:21; 1:45:55–1:48:44.]

## Considered Options

- An event grouping record with independent incident lifecycles, leaving creation sequence open.
- Security creates the master and selected initial child records during intake (discussed).
- Security creates only the master; specialists create all child records (discussed).
- Create incidents first and group them through subsequent analysis (late alternative, challenged).

## Decision Outcome

Chosen option: "An event grouping record with independent incident lifecycles, leaving creation sequence open", because the common requirement is event-level traceability and independently investigated children, not an agreed single creation sequence. Retain the logical event/master record and links to separately managed incidents. Creating or completing the master does not close child workflows, and closing one child does not close another. [S2 0:50:07–0:50:26; 1:14:46–1:17:43.]

The no-master-workflow direction is explicitly repeated. A parent completion indicator is then raised as a question, not selected. Likewise, mandatory master-before-child creation is no longer safe to state as settled: Security-first is revisited favorably at 1:38, while safety-led grouping after analysis is introduced and challenged at 1:47–1:49. Preserve both as alternatives for confirmation. [S2 1:15:35–1:17:03; 1:38:27–1:39:21; 1:47:56–1:49:31.]

The late discussion identifies the safety practitioner as responsible for assessing whether incidents belong together, collaborating with the other involved disciplines. This does not establish a monthly review cadence or shift all environmental responsibility to safety. Do not infer relatedness solely from nearby time/location; the examples explicitly distinguish a spill occurring earlier or from another cause. [S2 1:43:19–1:48:44.]

## Consequences

- Analysis: an explicit relationship-review responsibility supports correction without equating common time and place with a common cause.
- Analysis: reporting must distinguish event counts, individual injury cases, and other child incidents.
- Analysis: unsettled creation timing affects required relationships, orphan detection, handoff notifications, and duplicate-master handling; these cannot be finalized from this segment.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:02:41–0:04:01; 0:21:18–0:23:56; 0:43:41–0:48:21; 1:14:36–1:17:43; 1:43:19–1:49:31. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-118 text](../workshop-session-1/ADR-118-use-a-master-intake-with-independent-typed-incidents.md).
- Evidence nature: explicit common grouping requirement; conflicting initiation proposals. Confidence: high for grouping; low for creation sequence.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Resolve Security-first, specialist-child creation, and analysis-time event grouping after the lunch continuation.
- Unresolved: Confirm whether every incident must have a master immediately, eventually, or only when grouped. Preserve the standalone injury exception under ADR-123 pending this decision.
- Unresolved: Define authorized relinking and duplicate-master handling, including history and archive/delete policy.
- Unresolved: Confirm whether the master has only a derived completeness indicator or any separate review workflow; none is selected here.
- Unresolved: Terminology, effort/scope, and construction of the underlying model remain open.
- Related records: ADR-091, ADR-119, ADR-120, ADR-123, ADR-125, ADR-127. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
