---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Notifications
- Security intake
- Safety Management
- Environmental Management
- Clinic
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:32:05–0:43:19; 1:07:57–1:09:37; 1:16:02–1:16:28; 1:18:12–1:20:24)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-127: Notify Responsible Groups from Master Creation Without Waiting for Child Completion

## Context and Problem Statement

The discussion identifies a handoff gap when Security creates only a master: child-workflow notifications may not yet exist. Anonymous callers and callers other than the responsible leader make reliance on the caller insufficient. SIA explicitly asks whether master creation can notify a defined group, potentially according to initial severity, and receives an affirmative workshop answer. [S2 0:32:05–0:43:19; 1:07:57–1:09:37.]

## Decision Drivers

- Make key groups aware of a reported event without relying entirely on someone later remembering to telephone them. [S2 0:41:38–0:42:23; 1:08:21–1:09:09.]
- Allow notification on creation before every individual contributor is known. [S2 1:18:12–1:20:24.]
- Support urgency-sensitive notification where the eventual criteria require it. [S2 1:07:57–1:08:53; 1:16:02–1:16:28.]

## Considered Options

- A master-level group notification path plus separately defined child-workflow assignment.
- Notify only when a detailed child incident is created (handoff gap discussed).
- Rely solely on existing phone calls and the reporting individual to initiate every follow-up (discussed and challenged).

## Decision Outcome

Chosen option: "A master-level group notification path plus separately defined child-workflow assignment", because SIA explicitly wants relevant operational groups alerted that an event exists without waiting for detailed forms or final individual assignment. Configure the notification to identify the event and direct authorized recipients to it. Define the relevant safety/environmental audiences and include the clinic in the injury-related awareness path. Do not infer that all audiences receive every event or every clinical detail. [S2 1:07:57–1:09:37; 1:19:20–1:20:24.]

Initial urgency/severity may drive immediate alerts or escalation, but neither the severity scheme nor the exact triggers, recipients, timing, channels, or delivery guarantees are finalized. The urgent dispatch process still happens without waiting for computer entry. A notification is distinct from creating a child record, assigning an individual, granting edit permission, or verifying receipt. [S2 1:05:52–1:07:57; 1:16:02–1:16:28; 1:18:12–1:20:24.]

This requirement applies where a master is created at intake. If ADR-118 adopts analysis-time grouping, the operational event/incident alert trigger must be redefined so later grouping does not become a prerequisite for timely notification. [S2 1:47:56–1:49:31; implication is analysis.]

## Consequences

- Analysis: a distinct alert path can reduce the master-to-child handoff gap, but alerts alone do not ensure someone creates the missing incident.
- Analysis: recipient rules and message content must obey ADR-122 and avoid exposing unrestricted clinical narrative.
- Analysis: master and child alerts may duplicate notifications unless their purposes and triggers are distinguished.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:32:05–0:43:19; 1:07:57–1:09:37; 1:16:02–1:16:28; 1:18:12–1:20:24.
- Evidence nature: explicit requested handoff capability; detailed rules open. Confidence: high for notification requirement; medium for trigger design.
- New proposal, not approval or implementation evidence. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Select event creation trigger, incident-type versus urgency rules, recipient roles, channel, timing, fallback, and responsibility for rule maintenance.
- Unresolved: Confirm handling of masters with no child records, incomplete contributor data, or no response; assignment to safety and aging reports are discussed, not finalized. [S2 0:35:54–0:40:25.]
- Unresolved: Validate the workshop-described notification capability; no configured alert or delivery test is shown.
- Unresolved: Resolve creation sequence and final individual routing under ADR-118 and ADR-121.
- Related records: ADR-118, ADR-119, ADR-121, ADR-122. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
