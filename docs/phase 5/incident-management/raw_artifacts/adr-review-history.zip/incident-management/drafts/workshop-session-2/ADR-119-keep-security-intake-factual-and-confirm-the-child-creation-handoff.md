---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Security intake
- Clinic
- Safety Management
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:04:18–0:05:15; 0:21:18–0:40:25; 0:50:34–0:57:20; 1:03:46–1:14:01; 1:38:27–1:40:46; 1:47:56–1:49:31)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-119: Keep Security Intake Factual and Confirm the Child-Creation Handoff

## Context and Problem Statement

Session 1 proposed Security-led initial master creation. Session 2 distinguishes making the call, creating a master, selecting incident types, completing specialist forms, and assigning the contributor. The opening Security-only-master position changes as the group explores selected child creation, and the final portion considers later safety-led master creation. [S1 3:28:22–3:30:25; S2 0:27:54–0:30:41; 0:53:08–0:57:20; 1:38:27–1:40:46; 1:47:56–1:49:31.]

## Decision Drivers

- Keep the initial phone intake simple and avoid collecting detailed specialist forms before care or response. [S2 0:50:34–0:53:26; 1:04:06–1:06:43.]
- Capture facts and immediate response rather than speculative causes. [S2 1:11:10–1:12:49.]
- Avoid losing follow-up where the caller is anonymous, is the injured person, or is not the relevant leader. [S2 0:35:54–0:42:23.]

## Considered Options

- Security-led factual intake with an explicitly confirmed child-creation and assignment handoff.
- Security completes all detailed specialist data before handing off (discussed and challenged).
- Security creates only the master and relies on specialists to initiate children (discussed).
- Security selects incident categories to seed initial child records; specialists complete and extend them (discussed).

## Decision Outcome

Chosen option: "Security-led factual intake with an explicitly confirmed child-creation and assignment handoff", because the discussion repeatedly preserves a common reporting contact while limiting what must be collected initially. Capture what, where, when, the descriptive account available at the time, and immediate response actions. Avoid requiring suspected-cause speculation; the workshop direction favors removing that field from initial intake. Immediate actions include dispatch or referral activity rather than an unproven investigation conclusion. [S2 0:51:35–0:53:26; 1:11:10–1:12:49.]

Contact Security through the appropriate reporting channel; the emergency line is not established as mandatory for every routine PIT or damage report. Urgent dispatch and care must not wait for completion of computer-entry details. [S2 0:04:55–0:05:15; 1:05:52–1:06:43.]

Do not claim a final technical rule that Security creates all children or only the master. The discussion moves from specialists creating children, to Security selecting types that seed one child of each type, back toward Security initiating individual cases, then to a contested analysis-time grouping alternative. Each requires different data and notifications. Additional incidents may be added by authorized specialist/investigation users when discovered. [S2 0:27:54–0:30:41; 0:53:08–0:59:40; 1:38:27–1:39:21; 1:47:56–1:49:31.]

The intake user, caller, injured associate, accompanying management member, assigned supervisor, and later investigator are distinct roles. Recording the initial reporter does not by itself assign ownership of all follow-on work. Routing remains open under ADR-121; notifications are addressed in ADR-127. [S2 1:14:36–1:15:35; 1:18:12–1:21:38; 1:31:46–1:40:46.]

## Consequences

- Analysis: a factual intake reduces dependence on speculative diagnosis or root-cause claims at the phone call.
- Analysis: selecting incident types does not by itself settle how mandatory injured-person, severity, equipment, and assignment data will be supplied.
- Analysis: reliance on the caller as the automatic owner would leave unresolved anonymous-call and absent-supervisor cases.

## More Information

- Evidence: [Session 2](../../raw_artifacts/meeting_transcripts/workshop-session-2.txt), 0:04:18–0:05:15; 0:21:18–0:40:25; 0:50:34–0:57:20; 1:03:46–1:14:01; 1:38:27–1:40:46; 1:47:56–1:49:31. Prior evidence: [Session 1](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt) and [prior ADR-119 text](../workshop-session-1/ADR-119-route-initial-event-intake-through-security.md).
- Evidence nature: explicit requirements with changing ownership positions. Confidence: high for factual intake; low for final handoff.
- Revision of the same unapproved decision; preserve its ID and original draft date. This review copy does not supersede or overwrite the session 1 artifact. The supplied session ends for lunch, so later agreement must not be inferred.
- Unresolved: Confirm the master/child creation sequence in ADR-118 and exact handoff responsibility before configuring creation permissions.
- Unresolved: Define minimum fields, unknown-person behavior, and how one seeded injury is assigned correctly when several people are involved.
- Unresolved: Confirm contingency clinic master creation from session 1; session 2 does not settle it.
- Unresolved: Define continuity and supervisor fallback, reporting channels, and search access.
- Unresolved: Confirm whether immediate actions are copied to children; the workshop demonstrates configurability without choosing propagation or ongoing synchronization. [S2 1:12:56–1:14:01.]
- Related records: ADR-118, ADR-121, ADR-122, ADR-127, ADR-128. Resolve each ID through the [reconciliation plan](reconciliation-plan.md), which identifies its current proposal or retained source.
