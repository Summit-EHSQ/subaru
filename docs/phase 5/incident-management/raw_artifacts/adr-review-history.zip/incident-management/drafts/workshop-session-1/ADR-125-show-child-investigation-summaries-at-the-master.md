---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Reporting
- Action plans
- Witness information
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (1:51:33–1:52:08; 3:54:55–3:56:37)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-125: Show Child Investigation Summaries at the Master

## Context and Problem Statement

The closing review clarifies that the master’s sub-incident summary shows the action plans from its child incidents: three from one, one from another, and one from a third would appear as five in the summary. Witness information and possible cost rollups are also mentioned, without final collection rules. [3:54:55–3:56:37.]

## Decision Drivers

- See related impacts from a common event context. [1:51:33–1:52:08.]
- Understand the actions associated with the individual child investigations from the master. [3:54:55–3:56:20.]

## Considered Options

- Master-level summaries with child context and navigation.
- Inspect each child separately to find all actions (analyst-derived alternative).
- Copy all child investigation details into separately maintained master entries (analyst-derived alternative).

## Decision Outcome

Chosen option: "Master-level summaries with child context and navigation", because the reviewed master view is intended to summarize the investigation content associated with its children. Show the related child actions from the event context while retaining which child investigation owns them. The summary is a view of related information rather than evidence of separately maintained duplicate action records. [3:54:55–3:56:20; the avoidance of duplication is analysis.]

Apply ADR-122’s final access matrix to summary results and drill-through (analyst-derived safeguard following the stated separation of specialist detail). The transcript does not demonstrate permission-filtered aggregates or authorize exposure of restricted child details through the master. [2:11:01–2:11:35; 3:15:16–3:15:57.]

## Consequences

- Analysis: users can review event-level actions while preserving independent child ownership.
- Analysis: reporting must distinguish summary views from the underlying action records to avoid counting the same action twice.
- Analysis: counts, labels, and linked evidence can reveal restricted information, so summary access requires verification as well as child-form access.

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 1:51:33–1:52:08; 3:54:55–3:56:37. Evidence nature: explicit summary direction; permission behavior analyst-derived. Confidence: medium.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Confirm exactly which components are summarized: action plans are clearly explained; shared witnesses and costs are discussed without a final model.
- Unresolved: Confirm master-level versus child-level witness entry, sharing, and attribution; no common-witness copying rule is selected.
- Unresolved: Confirm whether costs will actually be collected, which amounts may be rolled up, and who may see them. Enthusiasm for a possible rollup is not acceptance of cost tracking.
- Unresolved: Validate summary filtering and drill-through under each representative, leadership, and specialist role.
- Related records: ADR-118, ADR-122. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
