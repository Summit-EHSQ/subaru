---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Employee Management
- Safety Management
- Clinic
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (1:08:20–1:15:51; 1:18:00–1:19:33; 1:23:08–1:34:31; 1:34:31–1:42:59)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-121: Use a Shared Investigation Team with the Injured Associate’s Supervisor

## Context and Problem Statement

SIA needs clinic, supervisor, and safety work to proceed in parallel. Sequential clinic and supervisor stages would block that work. A location-role investigation team is demonstrated; the team also identifies that the injured associate’s immediate supervisor must participate dynamically and may differ from the reporter. [1:08:20–1:15:51; 1:18:00–1:19:33; 1:34:31–1:42:59.]

## Decision Drivers

- Allow clinical updates and floor investigation to proceed without waiting for each other. [1:14:36–1:15:51.]
- Keep the injured associate’s immediate supervisor involved through investigation and countermeasure work. [1:38:25–1:42:38.]
- Retain safety as the party that checks completeness and approves the investigation. [1:23:08–1:23:44; 3:57:07–3:57:24.]

## Considered Options

- A shared investigation stage assigned to the relevant team and injured associate’s supervisor.
- Sequential clinic, supervisor, and safety stages (discussed and challenged).
- One investigator collects and enters everyone else’s information (discussed and challenged).
- Separate parallel contribution workflows (analyst-derived implementation alternative requiring fit assessment).

## Decision Outcome

Chosen option: "A shared investigation stage assigned to the relevant team and injured associate’s supervisor", because participants need to enter their own contributions during the same investigation period. Use location-based role membership for the stable safety/clinic team where it fits, and resolve the supervisor from the injured associate rather than the person reporting the event. Safety coordinates readiness for approval. [1:12:38–1:15:51; 1:34:31–1:42:59.]

This establishes parallel participation, not a verified concurrent-write mechanism. The transcript does not demonstrate combining a dynamic supervisor with the stable role, safe simultaneous saves, or user-specific field edit protection. Do not treat the location-role demonstration as proof of those capabilities. [1:24:03–1:30:29; 1:38:25–1:42:59.]

## Consequences

- Analysis: clinic and floor work can progress independently, but a shared stage still needs an explicit coordination and completion convention.
- Analysis: dynamic supervisor resolution depends on employee relationships being present and usable; ADR-060 does not establish that the required mapping is already configured.
- Analysis: a shared responsible group may permit members to edit one another’s content; checkboxes alone do not enforce separate authority. [1:26:22–1:30:29.]

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 1:08:20–1:15:51; 1:18:00–1:19:33; 1:23:08–1:34:31; 1:34:31–1:42:59. Evidence nature: explicit collaboration requirement; provisional routing mechanism. Confidence: medium.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Validate combined team/supervisor assignment, task visibility, and handling of missing or absent supervisors.
- Unresolved: Verify simultaneous-save behavior, lost-update protection, and attributable changes before accepting the shared-form mechanism.
- Unresolved: Confirm whether section completion indicators are needed and who can assert or reset them.
- Unresolved: Do not infer field-level security from hidden HTML; user-specific protection remains an unresolved design requirement where needed.
- Related records: ADR-060, ADR-120, ADR-122, ADR-123. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
