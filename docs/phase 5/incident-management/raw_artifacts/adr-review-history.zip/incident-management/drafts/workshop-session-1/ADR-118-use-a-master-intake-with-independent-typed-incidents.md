---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Safety Management
- Environmental Management
- Security intake
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (1:43:30–1:53:45; 2:17:45–2:25:26; 2:29:19–2:32:30; 3:53:40–3:54:50)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-118: Use a Master Intake with Independent Typed Incidents

## Context and Problem Statement

SIA identifies a gap in connecting the injuries, vehicle or property damage, and spills arising from one event. Maintaining links between every pair of incidents was demonstrated and challenged because each later record adds relationship maintenance. The closing recap returns to the master-incident direction. [Session 1, 1:43:30–1:53:45; 2:17:45–2:25:26; 3:53:40–3:54:50.]

## Decision Drivers

- Keep all consequences of the same event discoverable through one reference. [2:17:45–2:25:26.]
- Standardize intake for both single-impact and multi-impact events. [1:49:16–1:51:43; 2:24:08–2:25:26.]
- Give specialist teams independent investigations and completion times. [1:51:29–1:52:51; 3:54:31–3:54:50.]

## Considered Options

- A master intake with independently managed typed incident records.
- Separate typed incidents with manually maintained peer-to-peer links (demonstrated alternative).

## Decision Outcome

Chosen option: "A master intake with independently managed typed incident records", because SIA prefers one event reference over maintaining links among every related incident. Use the master as an intake and grouping record without its own investigation or approval workflow. Each child retains its own investigation, classification, actions, and lifecycle. Later-discovered impacts can be related to the event by authorized users. [2:24:08–2:25:26; 3:53:40–3:54:50.]

This is a logical design proposal. Summit Essentials was described as lacking this master concept; the demonstrated development-site behavior is not evidence that the requested configuration is built or included in the agreed effort. [2:23:22–2:23:47; 3:14:12–3:17:13.]

## Consequences

- Analysis: event navigation and reporting can follow one parent relationship, while specialist records retain separate accountability.
- Analysis: a master adds configuration, access rules, and relationship-maintenance behavior beyond the demonstrated Essentials baseline.
- Analysis: event totals must distinguish one event from multiple injury or other child cases; a master and its children must not be treated as equivalent counting units.

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 1:43:30–1:53:45; 2:17:45–2:25:26; 2:29:19–2:32:30; 3:53:40–3:54:50. Evidence nature: explicit. Confidence: high.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Confirm final terminology: primary incident was requested, but master incident remains in later discussion.
- Unresolved: Confirm whether every child must always have a master: the standard entry direction favors this, while the later clinic discussion permits an injury to become standalone (ADR-123).
- Unresolved: Confirm child-creation ownership, missed-child detection, duplicate-master correction, and effort/scope impact. Type selections in the demonstration did not create every repeated injury automatically. [2:30:30–2:32:21.]
- Unresolved: Keep ADR-091 unchanged: grouping impacts of one event under an intake is distinct from using an NCR to group repeat events.
- Related records: ADR-091, ADR-119, ADR-120, ADR-123, ADR-125. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
