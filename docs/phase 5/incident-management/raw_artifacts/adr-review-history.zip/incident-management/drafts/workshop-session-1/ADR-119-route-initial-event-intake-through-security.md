---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Security intake
- Clinic
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (1:45:02–1:50:42; 3:17:35–3:18:57; 3:28:22–3:30:25; 3:31:47–3:33:54)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-119: Route Initial Event Intake Through Security

## Context and Problem Statement

The team first identifies Security as the initial reporting point through 2222. Later it asks to let the clinic create a master for a walk-in, then returns to a unified Security route so dispatch activity has a common reporting hub. [1:45:02–1:50:42; 3:17:35–3:18:57; 3:28:22–3:30:25.]

## Decision Drivers

- Use a consistent point of intake and a common event reference. [1:49:16–1:50:42.]
- Give Security visibility of reported calls and support a unified reporting hub. [3:29:21–3:30:16.]
- Allow the clinic to continue caring for the associate while Security supplies the master reference. [3:29:05–3:30:21.]

## Considered Options

- Security creates the initial master, including when a person first presents at the clinic (later direction).
- Security and clinic both independently create master intake records (earlier direction).

## Decision Outcome

Chosen option: "Security creates the initial master, including when a person first presents at the clinic", because the later discussion favors one intake channel and Security reporting hub. For a walk-in, the clinic contacts Security to obtain the master reference while continuing care. [3:28:22–3:30:25.]

Treat this as the latest working direction within session 1. Do not infer a finalized technical prohibition on clinic creation: the earlier request explicitly granted it. Security intake does not mean Security must enter every specialist investigation or every subsequently discovered child. [3:17:35–3:18:57; 3:31:47–3:32:22.]

## Consequences

- Analysis: a common intake route makes Security reporting more consistent but makes master creation dependent on Security availability.
- Analysis: clinic and Security operating procedures must explain how to find an existing event before creating another master.
- Analysis: callers may identify an earlier event; authorized Security users need person-based lookup and an agreed handoff to the specialist team. [3:31:47–3:33:54.]

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 1:45:02–1:50:42; 3:17:35–3:18:57; 3:28:22–3:30:25; 3:31:47–3:33:54. Evidence nature: explicit, with an earlier conflicting direction. Confidence: high.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Resolve whether clinic creation remains a contingency permission or is removed; distinguish permission to create a master from permission to edit it or add children.
- Unresolved: Confirm intake fields, notification recipients, response expectations, and continuity when Security is unavailable.
- Unresolved: Person lookup was discussed; badge-number lookup, search coverage, and sensitive-detail visibility still require confirmation.
- Related records: ADR-118, ADR-122. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
