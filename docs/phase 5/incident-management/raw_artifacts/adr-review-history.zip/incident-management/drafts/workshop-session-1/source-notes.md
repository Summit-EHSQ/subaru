# Session 1 evidence notes

- Supplied file: Pasted text.txt, attachment directory 9949d1d8-a82a-48d9-8a05-64b79f24ebe2.
- Preserved source: [workshop-session-1.txt](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt).
- SHA-256: 1880edd88babd25fb0a86890e0449fc2f0e27766c6de42bf8352a7adf2dce385.
- Recording range: 0:00:04–4:01:23; includes a lunch gap from approximately 2:33 to 3:11.
- Workshop meeting date: not established by this transcript. 2026-11-10 is the proposal preparation date.
- This is the first of four sessions identified by the user; remaining transcripts are not included.
- Room audio is frequently attributed to Amanda Raver or Shao Ngoi even where multiple people appear to speak. Do not infer individual formal approval or assign a named decider from those labels.
- Literal transcription errors, including variants of Intelex, remain in the preserved source. ADR prose normalizes the clearly identifiable product name without altering the source.
- All citations in the draft package are source-file timestamps, not registered source identifiers.
- Existing ADR sources cited as Fourth transcript or Subsequent non-conformance design transcript have not been independently verified against original recordings in this request.
