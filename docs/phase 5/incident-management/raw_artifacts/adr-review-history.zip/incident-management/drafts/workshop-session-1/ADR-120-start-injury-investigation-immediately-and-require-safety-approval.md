---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Safety Management
- Clinic
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (0:54:51–0:55:26; 1:51:29–1:52:51; 1:53:45–2:00:12; 3:53:40–3:54:50; 3:56:40–3:57:34)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-120: Start Injury Investigation Immediately and Require Safety Approval

## Context and Problem Statement

The four-stage demonstration included draft and verification. SIA challenges these gates because the leadership member must begin investigation immediately and routing is expected to be predetermined. The closing recap confirms this direction for injury/illness and explicitly leaves other incident types for later sessions. Separate injured people require separate case details. [1:51:29–1:52:51; 1:53:45–2:00:12; 3:53:40–3:54:50.]

## Decision Drivers

- Avoid delaying investigation while another person validates the initial intake. [1:56:32–1:56:59.]
- Keep each injured person’s classification, treatment, and lost-time information distinct. [1:52:27–1:52:51.]
- Require a safety specialist to review each injury investigation. [3:56:40–3:57:24.]

## Considered Options

- Immediate injury investigation followed by per-case safety approval.
- Draft, verification, investigation, and approval for every injury (demonstrated baseline).

## Decision Outcome

Chosen option: "Immediate injury investigation followed by per-case safety approval", because SIA sees no useful preliminary validity gate and requires prompt investigation. Keep a distinct injury/illness record for each injured person within the event; multiple injury details for that person need not become separate event-level cases. Creating the injury record starts investigation without separate draft or verification gates. Each injury has its own safety-specialist approval rather than relying on a master-level approval. [0:54:51–0:55:26; 1:51:29–1:52:51; 1:56:32–2:00:12; 3:53:40–3:57:24.]

The closing discussion says safety approval closes the injury record. Earlier discussion describes monitoring before closure; the exact action-completion and effectiveness prerequisites remain unresolved. Do not extend the injury workflow to property, vehicle, environmental, or near-miss types until their sessions confirm it. [1:14:36–1:16:03; 3:54:01–3:54:17; 3:56:40–3:57:34.]

## Consequences

- Analysis: removing initial gates reduces handoffs but requires valid automatic assignments when the injury is created.
- Analysis: independent case approval allows different injuries from one event to complete at different times.
- Analysis: absence of a preliminary validity gate requires a clear exceptional handling path when investigation finds no incident or changes work-relatedness.

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 0:54:51–0:55:26; 1:51:29–1:52:51; 1:53:45–2:00:12; 3:53:40–3:54:50; 3:56:40–3:57:34. Evidence nature: explicit. Confidence: high.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Confirm closure prerequisites for open actions, clinical updates, and effectiveness monitoring; no fixed 30/60/90-day schedule is established.
- Unresolved: Confirm false-report closure versus cancellation or deletion policy; session discussion changes on this point.
- Unresolved: Confirm other incident-type workflows in sessions 2–4.
- Related records: ADR-118, ADR-121, ADR-124. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
