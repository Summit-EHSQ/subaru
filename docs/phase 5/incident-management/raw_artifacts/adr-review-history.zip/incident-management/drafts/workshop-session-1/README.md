# Proposed ADR List

Session 1 of four workshop sessions · Drafted 2026-11-10 · Status: proposed.

The repository already contains ADRs, so this package includes a [reconciliation plan covering every existing ADR](reconciliation-plan.md). The new records and the ADR-064 revision are review copies in this folder; canonical decisions remain unchanged.

## Event structure and workflow

| ADR ID | Title | Decision captured | Affected areas | Evidence | Confidence | Disposition |
|---|---|---|---|---|---|---|
| [ADR-118](ADR-118-use-a-master-intake-with-independent-typed-incidents.md) | Use a Master Intake with Independent Typed Incidents | Use one master intake to group independently managed typed incidents from the same event. | Incident Management, Safety Management, Environmental Management, Security intake | Session 1 1:43:30–1:53:45; 2:17:45–2:25:26; 2:29:19–2:32:30; 3:53:40–3:54:50 | high | draft |
| [ADR-119](ADR-119-route-initial-event-intake-through-security.md) | Route Initial Event Intake Through Security | Route initial event intake through Security, including clinic walk-ins, using the later session direction. | Incident Management, Security intake, Clinic | Session 1 1:45:02–1:50:42; 3:17:35–3:18:57; 3:28:22–3:30:25; 3:31:47–3:33:54 | high | draft |
| [ADR-120](ADR-120-start-injury-investigation-immediately-and-require-safety-approval.md) | Start Injury Investigation Immediately and Require Safety Approval | Start each injury case directly in investigation and require its own safety-specialist approval. | Incident Management, Safety Management, Clinic | Session 1 0:54:51–0:55:26; 1:51:29–1:52:51; 1:53:45–2:00:12; 3:53:40–3:54:50; 3:56:40–3:57:34 | high | draft |
| [ADR-121](ADR-121-use-a-shared-investigation-team-with-the-injured-associates-supervisor.md) | Use a Shared Investigation Team with the Injured Associate’s Supervisor | Let clinic, safety, and the injured associate’s supervisor contribute during the same investigation stage. | Incident Management, Employee Management, Safety Management, Clinic | Session 1 1:08:20–1:15:51; 1:18:00–1:19:33; 1:23:08–1:34:31; 1:34:31–1:42:59 | medium | draft |
| [ADR-122](ADR-122-scope-event-visibility-by-role-and-organizational-section.md) | Scope Event Visibility by Role and Organizational Section | Use role and organizational-section scope for general event visibility while defining sensitive child access separately. | Incident Management, Intelex Platform, Safety Management, Environmental Management, Security intake | Session 1 1:01:03–1:06:43; 2:11:01–2:11:35; 3:15:16–3:15:57; 3:19:20–3:23:07; 3:32:22–3:33:54 | medium | draft |
| [ADR-123](ADR-123-give-clinical-professionals-ongoing-injury-case-stewardship.md) | Give Clinical Professionals Ongoing Injury Case Stewardship | Let clinical professionals maintain evolving injury information and determine whether a case remains linked to an event. | Incident Management, Clinic, Safety Management, OHM | Session 1 0:58:00–1:00:33; 1:08:20–1:15:51; 3:35:20–3:42:32; 3:47:37–3:51:49 | high | draft |
| [ADR-124](ADR-124-vary-investigation-requirements-by-injury-severity.md) | Vary Investigation Requirements by Injury Severity | Configure injury investigation requirements by severity and use safety review to assess analysis quality. | Incident Management, Safety Management, Cause analysis, Action plans | Session 1 0:48:44–0:53:14; 1:08:20–1:09:50; 3:57:24–4:00:28 | medium | draft |
| [ADR-125](ADR-125-show-child-investigation-summaries-at-the-master.md) | Show Child Investigation Summaries at the Master | Expose child-investigation summaries from the master while retaining their child-record context. | Incident Management, Reporting, Action plans, Witness information | Session 1 1:51:33–1:52:08; 3:54:55–3:56:37 | medium | draft |

## Clinic integration

| ADR ID | Title | Decision captured | Affected areas | Evidence | Confidence | Disposition |
|---|---|---|---|---|---|---|
| [ADR-064](ADR-064-revision-defer-ohm-flow-selection-and-correlate-individual-injuries.md) | Defer OHM Flow Selection and Correlate Individual Injuries | Keep the clinic data-entry and exchange direction open, and match any updates to the specific injury rather than only the master. | Incident Management, OHM, Clinic, Employee Management | Session 1 3:44:10–3:53:32; existing ADR-064 | high | revise ADR-064 |

## Candidates needing clarification

These entries have no allocated ADR ID and no full ADR body. Their labels identify review topics, not registered decision identifiers.

| ADR ID | Title | Decision captured | Affected areas | Evidence | Confidence | Disposition |
|---|---|---|---|---|---|---|
| Not allocated | Configuration baseline | SIA prefers standard behavior where it fits; Summit Essentials is demonstrated, but selection of Essentials versus an extended native master configuration and the effort impact are not finalized. | Incident Management | Session 1 0:08:36–0:14:40; 3:14:12–3:17:13 | medium | needs clarification |
| Not allocated | Location and station model | Structured site/area values plus descriptive detail are favored; coordinate formats, station granularity, historical changes, source/import, and maintenance ownership need a decision. A custom plant map is an option, not a selected integration. | Incident Management | Session 1 0:36:42–0:47:48 | medium | needs clarification |
| Not allocated | Absence coverage and overdue escalation | Overdue reminders and manager reassignment are discussed; no escalation thresholds, recipient matrix, or automatic absence detection design is selected. The five-day example is not a requirement. | Incident Management | Session 1 0:53:23–0:54:51 | medium | needs clarification |
| Not allocated | Body-part selection and taxonomy | Diagram, hierarchy, search, and simplified lists are discussed without agreement on the final input method or hierarchy depth. Department-of-Labor demo lists are not adopted SIA master data. | Incident Management | Session 1 0:55:26–0:58:00 | medium | needs clarification |
| Not allocated | Contribution completion and form navigation | Section-complete checkboxes and scrolling versus tabs address missing contributions, but no final completion protocol or enforceable section authority is chosen. Validate with ADR-121. | Incident Management | Session 1 1:07:05–1:08:04; 1:23:34–1:30:29 | medium | needs clarification |
| Not allocated | Separate care/case-management application | A possible later clinical application is discussed; replacing OHM, choosing another Intelex application, or implementing that integration is not decided. Revisit alongside ADR-064. | Incident Management, Clinic | Session 1 1:31:37–1:34:02; 2:01:31–2:03:09 | medium | needs clarification |
| Not allocated | False reports, cancellation, and deletion | Early discussion proposes deletion; later discussion favors documenting and closing a false child incident. Empty-master handling, retention, cancellation, and delete authority remain unresolved. | Incident Management | Session 1 1:56:02–2:00:03; 3:23:12–3:25:41 | medium | needs clarification |
| Not allocated | Effectiveness monitoring and closure dependencies | Earlier monitoring-before-closure and later approval-closes-record statements require reconciliation. No firm 30/60/90-day monitoring schedule or dependency on open actions, NCRs, or CARs is selected. Preserve ADR-090 and ADR-091 boundaries. | Incident Management | Session 1 1:14:36–1:16:03; 3:56:40–3:57:34 | medium | needs clarification |
| Not allocated | Repeat injury reports and merge semantics | Reopening and historical OHM merging are discussed; preservation of reports, append versus merge, duplicate counts, and audit behavior are not defined. ADR-123 covers clinical ownership, not a selected destructive merge. | Incident Management, Clinic | Session 1 3:35:20–3:42:32 | medium | needs clarification |

## Review boundaries

- Only the first transcript is supplied. Environmental, property/vehicle, and near-miss workflows were deferred; the injury workflow is not automatically imposed on them.
- Review [source and evidence limitations](reconciliation-plan.md#traceability-and-gaps), especially the clinic-entry contingency, sensitive child access, severity changes, and closure/monitoring conflict.
- Confidence describes clarity of the evidence, not approval, technical feasibility, or design quality. Alternatives explicitly marked analyst-derived are not claimed as workshop debate. Consequences marked Analysis are architectural assessment.
- Source: [workshop-session-1.txt](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt). The original speaker labels are retained; several room speakers are attributed to one conferencing identity, so statements are cited by timestamp rather than inferred individual authority.
- For sessions 2–4, reconcile against this package as well as the canonical ADRs; preserve these proposed IDs rather than allocating duplicates.
