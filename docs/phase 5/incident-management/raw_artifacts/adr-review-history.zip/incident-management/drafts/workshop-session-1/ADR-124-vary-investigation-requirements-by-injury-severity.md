---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Safety Management
- Cause analysis
- Action plans
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (0:48:44–0:53:14; 1:08:20–1:09:50; 3:57:24–4:00:28)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-124: Vary Investigation Requirements by Injury Severity

## Context and Problem Statement

The demonstration shows severity-specific configuration for investigation tools and minimum child records. SIA confirms that its requirements vary by severity and describes specifically defined Five Whys expectations beyond the demonstrated generic presence checks. [0:48:44–0:53:14; 3:57:24–4:00:28.]

## Decision Drivers

- Make required investigation depth depend on severity. [3:57:24–3:57:40.]
- Support SIA’s defined cause-analysis expectations rather than assuming any entered analysis is sufficient. [3:59:17–4:00:28.]
- Allow safety to return insufficient investigation content for correction. [4:00:15–4:00:28.]

## Considered Options

- Severity-specific configured requirements with safety quality review.
- Identical investigation requirements for every injury (analyst-derived alternative).
- Use only optional analysis and unrestricted human discretion (analyst-derived alternative).

## Decision Outcome

Chosen option: "Severity-specific configured requirements with safety quality review", because SIA explicitly ties required content to injury severity and expects safety to judge whether the analysis meets its definitions. Prefer configurable requirement rules where the demonstrated behavior fits. Keep the immediate-investigation and safety-approval direction from ADR-120; severity-based demonstration examples do not authorize skipping those agreed injury stages. [3:53:40–3:57:40; 3:59:17–4:00:28.]

Do not set a final severity catalogue, numerical threshold, mandatory number of analysis records, or exact Five Whys structure from this session. The discussion distinguishes SIA’s five defined expectations from the demonstration’s generic checks; it does not establish that five arbitrary entries are sufficient. [3:58:37–4:00:28.]

## Consequences

- Analysis: configurable requirements can avoid separate workflows for every severity while keeping investigation depth distinct.
- Analysis: presence checks do not establish analytical quality, so safety review remains necessary.
- Analysis: a later clinical change may affect severity and required work; the session requests this behavior but does not define migration or approval-reset rules. [1:08:20–1:09:50.]

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 0:48:44–0:53:14; 1:08:20–1:09:50; 3:57:24–4:00:28. Evidence nature: explicit business direction; enforcement unresolved. Confidence: medium.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Obtain the controlled severity definitions and requirement matrix, including SIA’s exact Five Whys definitions and where they apply.
- Unresolved: Confirm which rules are native configuration and which require additional validation logic.
- Unresolved: Define re-evaluation when severity changes, including completed work, approvals, notifications, and reopening.
- Unresolved: Do not adopt example minor/moderate/major/catastrophic values or example minimum counts as confirmed SIA requirements.
- Related records: ADR-120, ADR-123. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
