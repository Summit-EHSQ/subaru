---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Intelex Platform
- Safety Management
- Environmental Management
- Security intake
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (1:01:03–1:06:43; 2:11:01–2:11:35; 3:15:16–3:15:57; 3:19:20–3:23:07; 3:32:22–3:33:54)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-122: Scope Event Visibility by Role and Organizational Section

## Context and Problem Statement

The afternoon discussion asks for leadership and safety visibility across the organization and manually selected floor safety representatives and environmental liaisons restricted to their organizational section. It explicitly distinguishes an organizational section from a form section. Earlier discussion says environmental participants need not see injured-person details just because the records share one event. [2:11:01–2:11:35; 3:19:20–3:23:07.]

## Decision Drivers

- Give leadership visibility across the organization and selected representatives visibility within their section. [3:20:17–3:21:33.]
- Support hand-maintained representative groups when employee attributes cannot identify them. [3:20:46–3:21:13.]
- Keep general event context distinguishable from specialist incident details. [2:11:01–2:11:35; 3:15:16–3:15:57.]

## Considered Options

- Role-based access with organizational scope and separately confirmed specialist-record access.
- One visibility scope for every user and all master/child content (analyst-derived alternative).
- Restrict all leadership to their own section (analyst-derived alternative).

## Decision Outcome

Chosen option: "Role-based access with organizational scope and separately confirmed specialist-record access", because SIA identifies distinct enterprise and section audiences. Propose organization-wide general event visibility for leadership and safety, and section-scoped visibility for explicitly maintained safety-representative and environmental-liaison groups. Other floor users receive no general incident-browsing entitlement merely by being employees. [3:19:20–3:21:43.]

The discussion names Security, clinic, environmental, and safety for master editing and adding children. Creation authority remains subject to the later Security-intake direction in ADR-119. Treat master access and child-detail access as separate entries in the permission matrix; the transcript does not settle visibility of medical notes or every injury field. [2:11:01–2:11:35; 3:22:31–3:23:07; 3:28:22–3:30:25.]

## Consequences

- Analysis: explicit representative membership adds administration but avoids granting section access to every floor employee.
- Analysis: parent summaries, searches, links, and child records need consistent effective permissions; access to the master must not be assumed to grant access to all medical detail.
- Analysis: clinic-provider account provisioning must be resolved without treating a medical provider automatically as a supplier-portal user; ADR-061 remains unchanged.

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 1:01:03–1:06:43; 2:11:01–2:11:35; 3:15:16–3:15:57; 3:19:20–3:23:07; 3:32:22–3:33:54. Evidence nature: explicit broad access direction; child-detail boundary unresolved. Confidence: medium.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Confirm whether broad leadership visibility applies to masters, all child types, or selected details; the conversation does not provide a complete medical-access matrix.
- Unresolved: Confirm location-of-event versus employee-home-section rules, cross-section cases, and membership ownership.
- Unresolved: Resolve workflow-responsibility access versus normal browsing scope and post-task visibility. The standard behavior was explained, not accepted as the final access model. [1:03:57–1:06:43.]
- Unresolved: Confirm Security person-search fields and results under the final permissions. [3:32:22–3:33:54.]
- Related records: ADR-061, ADR-082, ADR-119, ADR-121, ADR-125. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
