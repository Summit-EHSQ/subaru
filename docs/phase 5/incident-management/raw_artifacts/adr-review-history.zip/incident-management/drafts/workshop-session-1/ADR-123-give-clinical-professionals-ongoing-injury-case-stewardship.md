---
status: proposed
date: '2026-11-10'
decision-date: not-recorded-in-transcript
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Clinic
- Safety Management
- OHM
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (0:58:00–1:00:33; 1:08:20–1:15:51; 3:35:20–3:42:32; 3:47:37–3:51:49)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-123: Give Clinical Professionals Ongoing Injury Case Stewardship

## Context and Problem Statement

Clinical information can change while supervisors and safety are investigating, including treatment, lost time, recordability, and work-relatedness. Later examples distinguish an injury caused by an event from an unrelated repetitive-motion injury, and assign case-by-case clinical judgment to medical professionals. [1:08:20–1:15:51; 3:35:20–3:42:32; 3:46:28–3:47:37.]

## Decision Drivers

- Allow the clinic to update information without requiring the current investigator to transcribe each update. [0:59:41–1:00:33; 1:12:38–1:13:18.]
- Make injury-event association depend on clinical judgment in ambiguous cases. [3:39:00–3:40:36.]
- Avoid treating a corrected association as an additional injury solely because it moved outside the event. [3:35:20–3:38:23; 3:41:36–3:42:15.]

## Considered Options

- Ongoing clinical editing and case-by-case correction of injury-event association.
- Only the current workflow owner edits the injury after collecting clinic updates (discussed alternative).
- Always close and create a replacement injury when its event association changes (analyst-derived alternative).

## Decision Outcome

Chosen option: "Ongoing clinical editing and case-by-case correction of injury-event association", because SIA expects clinical professionals to own evolving injury information and the medical determination of whether it belongs to an event. Permit the clinic to update its injury information during investigation without waiting for a sequential clinic stage, and to detach an injury from the master when it is determined unrelated, keeping the injury as its own case. [1:08:20–1:15:51; 3:39:00–3:42:32.]

Retain an injury under its event when that event caused it even if the individual had relevant prior history. Reopening and combining repeat reports were discussed, but no final merge, counting, or retention rules were established. Direct clinic entry in Intelex remains contingent on clinic leadership confirmation described at the end of the session. [3:36:15–3:40:36; 3:48:03–3:51:49.]

## Consequences

- Analysis: clinical information and investigation progress need not share one completion date.
- Analysis: preserving a case while changing its event relationship avoids creating a replacement solely for relinking, but historical reporting needs a defined treatment of that change.
- Analysis: ongoing clinical editing needs explicit field and stage rules so a medical update does not silently invalidate an investigation approval.

## More Information

- Evidence: [Session 1 transcript](../../raw_artifacts/meeting_transcripts/workshop-session-1.txt), 0:58:00–1:00:33; 1:08:20–1:15:51; 3:35:20–3:42:32; 3:47:37–3:51:49. Evidence nature: explicit ownership direction; exact edit scope unresolved. Confidence: high.
- This is a proposal from session 1 of four; no exact decision date or formal approval is recorded. Demonstrated behavior has not been independently verified.
- Unresolved: Confirm clinic leadership agreement, account provisioning, precise edit authority, and post-closure update/reopening rules. The phrase full reign of editing does not establish delete authority.
- Unresolved: Confirm audit history for association changes and how a standalone case fits the standard master-intake direction (ADR-118).
- Unresolved: Define repeat-report merge versus append behavior, preservation of original reports, and counting rules; do not infer a destructive merge capability.
- Unresolved: Confirm which information lives in Intelex versus OHM through the revised ADR-064.
- Related records: ADR-064, ADR-118, ADR-121, ADR-122. References to ADR-064 in this package mean the proposed revision alongside this file; the canonical ADR remains unchanged.
