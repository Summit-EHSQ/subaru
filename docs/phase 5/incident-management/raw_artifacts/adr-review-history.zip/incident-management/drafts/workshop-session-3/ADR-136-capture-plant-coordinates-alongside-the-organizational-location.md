---
status: proposed
date: '2026-11-12'
discussion-date: '2026-11-04'
decision-date: not-formally-recorded
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Near-miss reporting
- Location reference data
- Reporting
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-3.txt (1:55:01–2:00:18 (P0447–P0471))'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-136: Capture Plant Coordinates Alongside the Organizational Location

## Context and Problem Statement

SIA reiterates that incidents and near misses need plant-specific coordinates for area analysis. The coordinates are based on building columns, with X/Y used in some shops and A/B in others. The existing organizational location structure supplies the location choices; areas beyond manufacturing and possible coordinate-to-shop derivation need review. [S3 1:55:01–2:00:18.]

## Decision Drivers

- Locate reports at the plant-area detail needed for safety review and trend analysis. [S3 1:55:01–1:56:30.]
- Support differing local coordinate conventions across shops. [S3 1:55:43–1:56:30.]
- Retain department/section/shop context using the established location structure. [S3 1:56:53–2:00:18.]

## Considered Options

- Capture plant coordinates with organizational location context.
- Use only a general world-map pin or organization value without local detail (analyst-derived alternative).
- Automatically derive all shop/location values from coordinates through a map integration (discussed possibility, not selected).

## Decision Outcome

Chosen option: "Capture plant coordinates with organizational location context", because SIA explicitly needs the local coordinate detail and agrees that location selections come from the location structure. Apply the requirement consistently to incident and prospective near-miss capture. Preserve which coordinate convention applies rather than treating A/B and X/Y as globally interchangeable values. [S3 1:55:01–1:58:59.]

Do not select a map provider, geographic conversion, automatic shop derivation, or a coordinate-range algorithm from this discussion. Those are possibilities raised for investigation. The presenter needs to examine the configured location structure, and non-manufacturing areas or service-parts coverage remain unresolved. [S3 1:56:30–2:00:18.]

This promotes the grounded location requirement from the session 1–2 clarification list into a draft; station history, maintenance ownership, pick-list depth, and detailed validation are still open. The operational incident location must not silently become an authentication or security rule simply because the same hierarchy also supports organizational scope. [S1 0:36:42–0:47:48; security separation is analysis under ADR-122.]

## Consequences

- Analysis: local coordinates support more specific reporting than general organizational location alone.
- Analysis: coordinate values require the convention and location context to avoid ambiguous comparisons.
- Analysis: map visualization can be added later without making it a prerequisite for recording the required detail.

## More Information

- Evidence: [Session 3 extraction](../../raw_artifacts/meeting_transcripts/workshop-session-3.txt), 1:55:01–2:00:18 (P0447–P0471); [original source DOCX](../../raw_artifacts/meeting_transcripts/workshop-session-3.docx). The recording header is dated 4 November 2026; drafting/revision date is 12 November 2026.
- Confidence: high for requirement; medium for implementation. Status is proposed; no formal approval, configured capability, deployment, or verified contractual change is claimed.
- Unresolved: Obtain example coordinate references/floor plans and review the current hierarchy.
- Unresolved: Define applicable areas, field types, validation, mandatory/unknown values, maintenance ownership, and historical changes.
- Unresolved: Confirm whether location is selected, inferred with confirmation, or both; automatic coordinate-to-shop mapping is not agreed.
- Unresolved: Clarify station granularity and any future map link, including areas outside the standard manufacturing list.
- Related records: ADR-082, ADR-122, ADR-133, ADR-134, ADR-135. Resolve the latest proposed/retained version through the [reconciliation plan](reconciliation-plan.md).
