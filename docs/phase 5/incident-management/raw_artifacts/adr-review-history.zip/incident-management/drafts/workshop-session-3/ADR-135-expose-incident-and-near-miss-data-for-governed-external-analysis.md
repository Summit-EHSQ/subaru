---
status: proposed
date: '2026-11-12'
discussion-date: '2026-11-04'
decision-date: not-formally-recorded
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Near-miss reporting
- Reporting
- External BI and AI
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-3.txt (1:28:47–1:33:25 (P0357–P0360); 1:49:51–1:54:19 (P0428–P0446); 2:00:18–2:02:54 (P0471–P0485))'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-135: Expose Incident and Near-Miss Data for Governed External Analysis

## Context and Problem Statement

SIA wants to examine a broad collection of near misses and incidents across locations and states of completion to find related concerns for safety review. The presenter distinguishes reporting/exporting stored data from analysis performed in another tool. OData, file export, and a possible SIA API/MCP route are mentioned; no delivery architecture is selected. [S3 1:28:47; 1:49:51–1:54:19; 2:00:18–2:00:43.]

## Decision Drivers

- Analyze recurring issues and related events without depending only on human memory. [S3 1:52:04–1:53:04.]
- Retrieve recorded location, time, category/severity, narrative, and analysis content where available. [S3 1:53:04–1:54:19.]
- Include imperfect or partially completed reports in later review rather than treating them as useless. [S3 1:28:47; 1:36:07–1:36:52.]

## Considered Options

- Provide governed recorded-data reports/exports for external analysis.
- Depend solely on users remembering earlier similar reports (discussed limitation).
- Assume a purchased built-in analytical AI component performs the requested analysis (not selected).

## Decision Outcome

Chosen option: "Provide governed recorded-data reports/exports for external analysis", because SIA explicitly asks for the recorded dataset and accepts an external-analysis boundary. Expose applicable stored incident/near-miss information with usable location, time, classification, status/completeness, narrative, and existing analysis fields where captured. Preserve source identity and missing-data meaning so incomplete entries are not mistaken for fully investigated cases; this last integrity detail is analyst-derived. [S3 1:28:47; 1:52:04–1:54:19.]

File formats such as CSV and a reporting/OData connector are workshop options, and SIA mentions API/MCP methods for text synthesis. Do not claim any connector is selected, configured, licensed, or tested, or that the broad dataset has been approved for an external AI service. Exact consumers, permitted fields, access, and refresh behavior remain design work. [S3 1:53:42–1:54:19; 2:00:18–2:00:43.]

Keep analytical synthesis distinct from the later discussion of an input-assistance AI feature for text quality/privacy. The earlier blanket statement that Intelex lacks AI is qualified by that later explanation; neither discussion proves purchase or deployment of a feature for this project. [S3 1:54:19; 2:00:43–2:02:54.]

## Consequences

- Analysis: trend analysis can use recorded facts without adding an unapproved in-application AI workflow.
- Analysis: useful external analysis depends on consistent location/classification data and explicit treatment of missing information.
- Analysis: exports can carry sensitive narrative; field-level content and consumer permissions need to align with ADR-122.

## More Information

- Evidence: [Session 3 extraction](../../raw_artifacts/meeting_transcripts/workshop-session-3.txt), 1:28:47–1:33:25 (P0357–P0360); 1:49:51–1:54:19 (P0428–P0446); 2:00:18–2:02:54 (P0471–P0485); [original source DOCX](../../raw_artifacts/meeting_transcripts/workshop-session-3.docx). The recording header is dated 4 November 2026; drafting/revision date is 12 November 2026.
- Confidence: high for export need; medium for delivery method. Status is proposed; no formal approval, configured capability, deployment, or verified contractual change is claimed.
- Unresolved: Define dataset audience, fields, status coverage, identifiers, filtering, security, refresh, volume, and format.
- Unresolved: Select file export, reporting connector, or API/MCP only after confirming the receiving analysis tool and requirements.
- Unresolved: Keep automated event matching or AI-derived conclusions advisory until reviewed; no automatic relinking is selected.
- Unresolved: Confirm near-miss platform availability; the dataset cannot assume all near misses originate in Intelex until ADR-134 is resolved.
- Related records: ADR-118, ADR-122, ADR-133, ADR-134, ADR-136. Resolve the latest proposed/retained version through the [reconciliation plan](reconciliation-plan.md).
