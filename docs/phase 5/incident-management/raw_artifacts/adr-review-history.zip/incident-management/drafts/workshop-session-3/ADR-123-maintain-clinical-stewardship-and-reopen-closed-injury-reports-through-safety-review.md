---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-12'
discussion-date: '2026-11-04'
decision-date: not-formally-recorded
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- Clinic
- Safety Management
- OHM
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-3.txt (1:50–2:29 (P0009–P0010); 8:38–12:23 (P0030–P0055))'
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:29:06–0:30:33; 1:24:19–1:28:24; 1:35:26–1:36:17)'
- '../../raw_artifacts/meeting_transcripts/workshop-session-1.txt (prior decision evidence; see linked session 1 text)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-123: Maintain Clinical Stewardship and Reopen Closed Injury Reports Through Safety Review

## Context and Problem Statement

Session 3 permits clinical contribution while Safety owns the review. It then explains that work-relatedness can change days, weeks, or months later and that clinical judgment, potentially with Safety, determines the change. The proposed closed-case response is reopening into Safety review and returning to manager review. [S3 1:50; 8:38–12:23.]

## Decision Drivers

- Allow clinical information to be entered while Safety progresses its review. [S3 1:50.]
- Allow reassessment after a report has closed because the medical conclusion can arrive much later. [S3 9:17–11:36.]
- Re-review a changed report through Safety and the Safety Manager. [S3 11:43–12:23.]

## Considered Options

- Clinical stewardship with parallel contribution during Safety review and controlled reopening for later changes.
- Leave closed injury reports immutable regardless of later clinical conclusions (analyst-derived alternative).
- Treat every late clinical change as a new injury report (analyst-derived alternative).

## Decision Outcome

Chosen option: "Clinical stewardship with parallel contribution during Safety review and controlled reopening for later changes", because the session explicitly accommodates clinical updates after initial reporting and closure. During Safety-owned review, permit clinic entry of injury classifications and medical details. Medical work-relatedness and the interpretation of prior conditions remain clinical judgments, with Safety involvement where needed. [S3 1:50; 9:17–11:36.]

When a closed injury needs revision, reopen it into Safety review and submit the revised outcome for Safety Manager review again. This is a working flow described by the presenter and acknowledged in the session, not proof that reopening is configured. [S3 11:43–12:23.]

Do not automatically cancel a report solely because a later work-relatedness classification changes: the discussion distinguishes a truly invalid report from clinical reclassification, but does not finish every cancellation/status rule. Retain the earlier ability to correct an injury’s event association through clinical judgment; the revised ADR-118 no longer requires a master at intake. Merge/append and counting rules remain open. [S3 10:04–11:43; S1 3:39:00–3:42:32.]

## Consequences

- Analysis: later medical conclusions can correct a case without automatically generating a duplicate injury.
- Analysis: reopening needs attributable history and clear treatment of the prior approval/reporting state.
- Analysis: clinical access during Safety review is specified, but broad unrestricted clinical edits across every stage are not established.

## More Information

- Evidence: [Session 3 extraction](../../raw_artifacts/meeting_transcripts/workshop-session-3.txt), 1:50–2:29 (P0009–P0010); 8:38–12:23 (P0030–P0055); [original source DOCX](../../raw_artifacts/meeting_transcripts/workshop-session-3.docx). The recording header is dated 4 November 2026; drafting/revision date is 12 November 2026.
- Confidence: high. Status is proposed; no formal approval, configured capability, deployment, or verified contractual change is claimed.
- Prior review text and evidence: [ADR-123](../workshop-session-2/ADR-123-retain-clinical-stewardship-while-confirming-contribution-access-across-stages.md). Earlier S1/S2 source links and locators remain in that history; this full replacement carries the continuing decision boundary forward.
- Unresolved: Define who initiates reopening, required reasons, status history, and notification/reapproval rules.
- Unresolved: Confirm editing during supervisor review, manager review, and after closure; only the Safety-review concurrency is explicit here.
- Unresolved: Define cancellation versus non-work-related classification, reporting/counting implications, and retained evidence.
- Unresolved: Keep OHM ownership, interface direction, clinic leadership agreement, and repeat-report merge semantics unresolved.
- Related records: ADR-064, ADR-118, ADR-120, ADR-121, ADR-122, ADR-128. Resolve the latest proposed/retained version through the [reconciliation plan](reconciliation-plan.md).
