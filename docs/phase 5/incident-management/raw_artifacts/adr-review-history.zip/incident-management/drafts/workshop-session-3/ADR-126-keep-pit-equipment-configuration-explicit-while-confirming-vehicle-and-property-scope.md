---
status: proposed
date: '2026-11-10'
revision-date: '2026-11-12'
discussion-date: '2026-11-04'
decision-date: not-formally-recorded
deciders: []
consulted: []
informed: []
primary-application: Incident Management
secondary-applications:
- PIT safety
- Property damage
- Vehicle incidents
source_references:
- '../../raw_artifacts/meeting_transcripts/workshop-session-3.txt (0:10–7:37 (P0007–P0022))'
- '../../raw_artifacts/meeting_transcripts/workshop-session-2.txt (0:04:18–0:19:45; 0:24:32–0:27:06; 1:14:13–1:14:26)'
supersedes: []
superseded_by: []
approval_references: []
---

# ADR-126: Keep PIT Equipment Configuration Explicit While Confirming Vehicle and Property Scope

## Context and Problem Statement

Session 2 established the need to identify PIT and vary questions by equipment. Session 3 discusses injury, property, industrial/non-production vehicles, and PIT subcategories, but the presenter notes that vehicle incidents are not explicitly listed in the statement of work and takes inclusion back for clarification. [S2 0:05:15–0:12:33; S3 3:39–4:50.]

## Decision Drivers

- Keep equipment-specific questions and PIT distinctions recognizable. [S2 0:08:51–0:12:33.]
- Avoid confusion between a production vehicle being damaged and an industrial/non-production vehicle incident. [S3 3:39–4:17.]
- Confirm the scoped incident catalogue before treating every proposed vehicle variant as included. [S3 4:50.]

## Considered Options

- Explicit PIT/equipment configuration with vehicle/property taxonomy and scope confirmation.
- Rename all property damage to PIT (earlier ambiguity).
- Treat all suggested vehicle categories as approved scope (analyst-derived alternative).

## Decision Outcome

Chosen option: "Explicit PIT/equipment configuration with vehicle/property taxonomy and scope confirmation", because the business distinction remains useful while the session explicitly parks broader vehicle inclusion. Retain equipment-dependent PIT questions from the prior proposal. Apply the proposed PIT driver-supervisor first pass, initial Five Whys/temporary measures, Safety finalization, and manager review through ADR-120. [S2 0:08:51–0:12:33; S3 0:10–3:12; 4:50.]

Do not finalize a new industrial/non-production vehicle label, native object/subtype arrangement, or coverage of all property/other vehicle cases from the discussion. The presenter’s report that vehicle incidents are not called out in the SOW is evidence of a scope question, not independently verified contract content or an approved exclusion. [S3 3:39–4:50.]

## Consequences

- Analysis: equipment-aware configuration can be retained without committing the project to an unconfirmed vehicle catalogue.
- Analysis: intake training, field lists, and reporting filters depend on the eventual taxonomy and scope outcome.

## More Information

- Evidence: [Session 3 extraction](../../raw_artifacts/meeting_transcripts/workshop-session-3.txt), 0:10–7:37 (P0007–P0022); [original source DOCX](../../raw_artifacts/meeting_transcripts/workshop-session-3.docx). The recording header is dated 4 November 2026; drafting/revision date is 12 November 2026.
- Confidence: medium. Status is proposed; no formal approval, configured capability, deployment, or verified contractual change is claimed.
- Prior review text and evidence: [ADR-126](../workshop-session-2/ADR-126-distinguish-pit-incidents-and-vary-their-questions-by-equipment-type.md). Earlier S1/S2 source links and locators remain in that history; this full replacement carries the continuing decision boundary forward.
- Unresolved: Obtain the SOW scope determination and confirm the PIT/property/vehicle catalogue and labels.
- Unresolved: Validate the actual PIT form/Visio, equipment categories, crane differences, and assignment exceptions; those artifacts remain unsupplied.
- Unresolved: Retain open cost-capture and aggregation rules from session 2.
- Related records: ADR-119, ADR-120, ADR-124, ADR-125, ADR-129. Resolve the latest proposed/retained version through the [reconciliation plan](reconciliation-plan.md).
